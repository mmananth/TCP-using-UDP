 #################################### 
 # 			Downloaded From			#
 #		Another Computer Blog		#
 #									#
 # http://akomaenablog.blogspot.com #
 #									#
 #	http://computersblog.comoj.com	#
 #									#
 # 		akoma1blog@yahoo.com		#
 #									#
 ####################################